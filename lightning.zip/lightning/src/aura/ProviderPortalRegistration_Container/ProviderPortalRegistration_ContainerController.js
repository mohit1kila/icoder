({
    myAction : function(component, event, helper)
    {
        console.log("myAction from ProviderPortalRegistration_Container");
    },
	myCustomAction : function() // when this is executed as the app script, component, event, helper will not be available
    {
        // You can obtain the instance of the component this way
        var component = this.$cmp$; // Which intern gives you access to all controller functions
		console.log("overrides the app.js URI with a controller function", component.get("c.myAction").$meth$);
	},
    // Used as an example to call the Apex Class ProviderPortalRegistrationDummyApexClass
    callDummyMethod : function(component, event, helper)
    {
        // create the object, must match the properties of the Apex class
        var reqObj = {param1:"param1",param2:"param2"};
        
        // get the Apex Controller action
    	var dummyMethodAction = component.get("c.dummyMethod");
        // Serialize the request Object
        dummyMethodAction.setParams({reqJSON : $A.util.json.encode(reqObj)});
        // Set response callback
        dummyMethodAction.setCallback(this, function(action, component)
        {
            // The returnValue in the response will be in the form of a JavaScript object
            console.log("dummyMethodAction state and response", action.state, action.returnValue);
        });
        // Queue service action
        $A.enqueueAction(dummyMethodAction);
	},
    app : function(component, event, helper) 
    {
        require(["require", "jquery", "angular", "ngAnimate", "ng-fx"], function(require)
        {
            var $ = require("jquery");
            var angular = require("angular");
            
            //---------------------------------------------------------------------------------------------------------
            var app = angular.module("app", ["ng", "ngAnimate", "ng-fx"]);
            app.controller("ctrl", ["$scope", "$animate", "$timeout", "$interval",
				function($scope, $animate, $timeout, $interval)
                {
                    $("#loadingWheelOverlay").fadeOut(1000);
                    var screens = ["PrescriberOrOfficeStaffScreen", "GetStartedScreen", "PrescriberInformationScreen", "SiteInformationScreen", "AccountPreferencesScreen", "DoneScreen"];
                    var count=1;
                    $scope.animation = "fade-up";
                    $scope.screen = "PrescriberOrOfficeStaffScreen";
                    $scope.prescriberLicenses = [null];
                    $scope.addPrescriberLicenses = function()
                    {
                        $scope.prescriberLicenses.push(null);
                    };
                    
                    $scope.switchScreen = function(screen)
                    {
                        switch(screen)
                        {
                            case "PrescriberInformationScreen":
                                $scope.progressScreen1 = "slds-is-current";
                        		$scope.progressScreen2 = "slds-is-incomplete";
                        		$scope.progressScreen3 = "slds-is-incomplete";
                                break;
                            case "SiteInformationScreen":
                                $scope.progressScreen1 = "slds-is-complete";
                        		$scope.progressScreen2 = "slds-is-current";
                        		$scope.progressScreen3 = "slds-is-incomplete";
                                break;
                            case "AccountPreferencesScreen":
                                $scope.progressScreen1 = "slds-is-complete";
                        		$scope.progressScreen2 = "slds-is-complete";
                        		$scope.progressScreen3 = "slds-is-current";
                                break;
                        }
                        
                        $scope.registrationAnimationContainerAdjustment = $($('[data-ng-switch-when].registration-animation-container')[0]).height();
                        $scope.screen = screen;
                    };
                    $scope.switchBack = function(screen)
                    {
                        $scope.animation = "fade-down";
                        $timeout(function(){$scope.switchScreen(screen);},0);
                    };
                    $scope.switchTo = function(screen)
                    {
                        $scope.animation = "fade-up";
                        $timeout(function(){$scope.switchScreen(screen);},0);  
                    };
                    $scope.showSearchResults = function()
                    {
                        $scope.showSearchResultsTable = true;
                    };
                    /*var interval = $interval(function()
                    {
                        //if(count >= screens.length){$interval.cancel(interval); $scope.screen = "PrescriberOrOfficeStaffScreen"; return;}
                        if(count >= screens.length){count=0;}
                        $scope.screen = screens[count];
                        count++;
                    }, 5000);*/
                    
                    $animate.on("enter", $("#registrationForm"), function(element, phase)
					{
						if (phase === "start")
						{
							/*if ($scope.animation === "fade-up")
							{
								$scope.registrationAnimationContainerAdjustment = $($('[data-ng-switch-when].registration-animation-container')[0]).height();
							}
							else if ($scope.animation === "fade-down")
							{
								$scope.registrationAnimationContainerAdjustment = $($('[data-ng-switch-when].registration-animation-container')[0]).height();
							}*/
                            // FIXME: This is a hack to make the animations smooth
                            /*switch($scope.screen)
                            {
                                case screens[0]:
                                    $scope.registrationAnimationContainerAdjustment = 60;
                                    break;
                                case screens[1]:
                                    $scope.registrationAnimationContainerAdjustment = 462;
                                    break;
                                case screens[2]:
                                    $scope.registrationAnimationContainerAdjustment = 236;
                                    break;
                                case screens[3]:
                                    $scope.registrationAnimationContainerAdjustment = 780;
                                    break;
                                case screens[4]:
                                    $scope.registrationAnimationContainerAdjustment = 289;
                                    break;
                                case screens[5]:
                                    $scope.registrationAnimationContainerAdjustment = 289;
                                    break;
                            }*/
						}
						else if (phase === "close")
						{
							$scope.slideTransitionLocked = false;
						}
					});
					$animate.on("leave", $("#registrationForm"), function(element, phase)
					{
						if (phase === "close")
						{
							$scope.slideTransitionLocked = false;
						}
					});
                }]);
            
            angular.bootstrap($("#app"), ["app"]);
        });
	}
})