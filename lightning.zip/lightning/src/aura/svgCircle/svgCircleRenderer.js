({
	render: function(component, helper) 
    {
        // Get attributes from the component markup
       	var cx = component.get("v.cx");
        var cy = component.get("v.cx");
        var r = component.get("v.radius");
        var stroke = component.get("v.stroke");
        var strokeWidth = component.get("v.strokeWidth");
        var fill = component.get("v.fill");
        var ngShow = component.get("v.ngShow");
        
        // Create and return SVG circle element
        var circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        cx && circle.setAttribute("cx", cx);
        cy && circle.setAttribute("cy", cy);
        r && circle.setAttribute("r", r);
        stroke && circle.setAttribute("stroke", stroke);
        strokeWidth && circle.setAttribute("stroke-width", strokeWidth);
        fill && circle.setAttribute("fill", fill);
        ngShow && circle.setAttribute("data-ng-show", ngShow);
        return circle;
    }
})