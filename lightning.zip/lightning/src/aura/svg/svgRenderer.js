({
    render: function(component, helper) 
    {
        var nestedElements = component.superRender();
        
        //grab attributes from the component markup
        var classname = component.get("v.class");
        var xlinkhref = component.get("v.xlinkHref");
        var ariaHidden = component.get("v.ariaHidden");
        var ngIf = component.get("v.ngIf");
        var ngClick = component.get("v.ngClick");
        var height = component.get("v.height");
        var width = component.get("v.width");
        var style = component.get("v.style");
        var viewBox = component.get("v.viewBox");
        var preserveAspectRatio = component.get("v.preserveAspectRatio");
        
        //return an svg element w/ the attributes
        var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        height && svg.setAttribute("height", height);
        width && svg.setAttribute("width", width);
        classname && svg.setAttribute('class', classname);
        svg.setAttribute('aria-hidden', ariaHidden);
        ngIf && svg.setAttribute("data-ng-if", ngIf);
        ngClick && (svg.setAttribute("data-ng-click", ngClick));
        xlinkhref && (svg.innerHTML += '<use xlink:href="'+xlinkhref+'"></use>');
        //FIXME: This WILL break in IE, uses classes and CSS stylesheets as a workaround 
        style && (svg.setAttribute("style", style));
        viewBox && (svg.setAttribute("viewBox", viewBox));
        preserveAspectRatio && (svg.setAttribute("preserveAspectRatio", preserveAspectRatio));
        for(var inc=0,len=nestedElements.length; inc<len; inc++)
        {
            svg.appendChild(nestedElements[inc]);
        }
        return svg;
    }
})