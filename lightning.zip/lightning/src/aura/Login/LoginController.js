(
{
	doaction: function(component, event, helper)
	{
		var inputCmpUserName = component.find("UserName");
		var inputCmppassword = component.find("userPassword");
		var inputCmpComfirmPassword = component.find("userConfirmPassword");
		var strUserName = inputCmpUserName.get("v.value");
		var strUserpassowrd = inputCmppassword.get("v.value");
		var strconfrimPassword = inputCmpComfirmPassword.get("v.value");
		var isErrorFlag = false;
		if (typeof strUserName == 'undefined')
		{
			inputCmpUserName.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmpUserName.set("v.errors", "");
		}
		if (typeof strUserpassowrd == 'undefined')
		{
			inputCmppassword.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmppassword.set("v.errors", "");
		}
		if (typeof strconfrimPassword == 'undefined')
		{
			inputCmpComfirmPassword.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmpComfirmPassword.set("v.errors", "");
		}
		if (!isErrorFlag)
		{
			if (strUserpassowrd != strconfrimPassword)
			{
				inputCmppassword.set("v.errors", [
				{
					message: "Password and Confirm Password is not matched."
				}]);
				isErrorFlag = true;
				inputCmppassword.set("v.value", "");
				inputCmpComfirmPassword.set("v.value", "");
			}
		}
		if (!isErrorFlag)
		{
			var action = component.get("c.IsExistingEmail");
			action.setParams(
			{
				strEmail: strUserName
			});
			action.setCallback(this, function(a)
			{
				if (a.getState() === "SUCCESS")
				{
                    if (a.getReturnValue() != null && a.getReturnValue()!='')
					{
						inputCmpUserName.set("v.errors", [{	message: a.getReturnValue()}]);
					}
					else
					{
                        
                        var objUserDetail=component.get("v.objUserDetail");
                        objUserDetail={};
                        alert('hello1');
                        objUserDetail.username=strUserName;
                        objUserDetail.password=strUserpassowrd;
                        component.set("v.objUserDetail",objUserDetail);
                     
                
                        
                        
						//alert('in else'+a.getReturnValue());
						var appEvent = $A.get("e.c:ankitProviderEvent");
                        appEvent.setParams({ "stepTOMove" : "Provider",
                                           	  "objUserDetail" : objUserDetail
                                           }
                                          );
                       
                        appEvent.fire();
                        alert('hello3');
                        
                        
                                
                     /* var SetValueEvent = $A.get("e.c:UpdateProviderRegInfo");
                       SetValueEvent.setParams({ "objWrapperUserDetail" : objUserDetail });
                        
                        SetValueEvent.fire();
                        alert('SetValueEvent');*/
					}
				}
				else if (a.getState() === "ERROR")
				{
					alert('in else');
					$A.log("Errors", a.getError());
				}
			});
			$A.enqueueAction(action);
		}
	}
})