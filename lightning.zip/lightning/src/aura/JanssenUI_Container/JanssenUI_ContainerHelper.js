({
    getFormattedGlobalId : function(component) 
    {
        return "GID_"+component.get("globalId").replace(/[:;]/g, "_");
    },
	// Push the instance of the component's helper to the JanssenUI global INSTANCE_STORE
    // Not calling this will default to the super component's helper
    registerHelper : function(component, helper)
    {
        if(typeof window.JanssenUI !== "undefined" && window.JanssenUI.INSTANCE_STORE && window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] && (window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)].helper !== helper))
        {
            window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)].helper = helper;
        }
    }
})