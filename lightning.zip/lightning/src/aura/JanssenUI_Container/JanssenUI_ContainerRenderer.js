({
	// Your renderer method overrides go here
	render: function (component, helper) 
    {
        var render = this.superRender();
        // Decorate with the unique global ID
        //var globalId = component.getGlobalId();
        return render;
    },
    
    afterRender  : function(component, helper)
    {
        // Run afterRender functions from JanssenUI.AFTER_RENDER_STORE
        if(window.JanssenUI.AFTER_RENDER_STORE)
        {
            for(var inc=0,len=window.JanssenUI.AFTER_RENDER_STORE.length; inc<len; inc++)
            {
                window.JanssenUI.AFTER_RENDER_STORE[inc]();
            }
        }
        
        // After render emit appReady event to report that it's finished
		window.JanssenUI.APP_READY_EVENTS.RENDER_COMPLETE_EVENT.fire();
    }
})