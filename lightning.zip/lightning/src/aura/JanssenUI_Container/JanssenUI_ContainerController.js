({
    init : function(component, event, helper) 
    {
        // Set properties in the JanssenUI global
        //var INSTANCE_STORE = {};
        var RENDER_COMPLETE_EVENT = component.getEvent("AppReady");
        var AMD_LOADED_EVENT = component.getEvent("AppReady");
        if(typeof window.JanssenUI !== "undefined")
        {
            //window.JanssenUI.INSTANCE_STORE = INSTANCE_STORE;
            window.JanssenUI.APP_READY_EVENTS = {RENDER_COMPLETE_EVENT : RENDER_COMPLETE_EVENT, AMD_LOADED_EVENT : AMD_LOADED_EVENT};
        }
        else
        {
            window.JanssenUI = {
                //INSTANCE_STORE : INSTANCE_STORE,
                APP_READY_EVENTS : {RENDER_COMPLETE_EVENT : RENDER_COMPLETE_EVENT, AMD_LOADED_EVENT : AMD_LOADED_EVENT}
            };
        }
        
        // Push the instance of container to the JanssenUI global INSTANCE_STORE
        if(typeof window.JanssenUI !== "undefined")
        {
            // TODO: put an Object check here for JanssenUI.APP_READY_CALLBACKS
            if(window.JanssenUI.INSTANCE_STORE)
            {
                window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
            }
            else
            {
                window.JanssenUI.INSTANCE_STORE = {};
                window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
            }
        }
        else
        {
            window.JanssenUI = {INSTANCE_STORE : {}};
            window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
        }
        
        // explicitally set the v.loadAppScript to false to prevent loading of the app script, shouldn't be needed, but just in case
        component.set("v.loadAppScript", false);
    },
    handleAppReady : function(component, event, helper)
    {
        if(window.JanssenUI.APP_READY_EVENTS.RENDER_COMPLETE_EVENT.$fired$ && window.JanssenUI.APP_READY_EVENTS.AMD_LOADED_EVENT.$fired$)
        {
            var appScript = component.get("v.appScript");
            if(typeof appScript === "string" && appScript)
            {
                component.set("v.loadAppScript", true);        
            }
            else if(typeof appScript === "object" && appScript.$meth$ && typeof appScript.$meth$ === "function")
            {
                appScript.$meth$(); 
            }
            
            // Define all the component modules
            if(window.JanssenUI.COMPONENT_MODULES)
            {
                for(var prop in window.JanssenUI.COMPONENT_MODULES)
                {
                    if(window.JanssenUI.COMPONENT_MODULES.hasOwnProperty(prop))
                    {
                        window.JanssenUI.COMPONENT_MODULES[prop]();
                    }
                }
            }
            // Excecute all the AppReady callbacks of all c:JanssenUI_BaseComponent components
            if(window.JanssenUI.APP_READY_CALLBACKS)
            {
                for(var inc=0, len=window.JanssenUI.APP_READY_CALLBACKS.length; inc<len; inc++)
                {
                    // forcing async for performance reasons
                    setTimeout(window.JanssenUI.APP_READY_CALLBACKS[inc],0);
                }
            }
        }
    }
})