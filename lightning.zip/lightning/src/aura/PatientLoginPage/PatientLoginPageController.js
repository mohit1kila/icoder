({
	ValidateUserDetail : function(component, event, helper) 
    {
		
    	
    	var inputLastName = component.find("LastName");
		var inputCmpUserName = component.find("UserName");
		var inputCmppassword = component.find("userPassword");
		var inputCmpComfirmPassword = component.find("userConfirmPassword");
		var strUserName = inputCmpUserName.get("v.value");
		var strUserpassowrd = inputCmppassword.get("v.value");
		var strconfrimPassword = inputCmpComfirmPassword.get("v.value");
        var isAboveighteenAge= component.find("isAboveage");
        var isTermCondition = component.find("termcondition");

		var isErrorFlag = false;
        
      if ( isAboveighteenAge.get("v.value") == false)
		{

			isAboveighteenAge.set("v.errors", [
			{
				message: "Please validate your age."
			}]);
			isErrorFlag = true;
		}
		else
		{
			isAboveighteenAge.set("v.errors", "");
		}
		if ( isTermCondition.get("v.value") == false)
		{

			isTermCondition.set("v.errors", [
			{
				message: "Please aceept term and condition."
			}]);
			isErrorFlag = true;
		}
		else
		{
			isTermCondition.set("v.errors", "");
		}


        if (typeof inputLastName.get("v.value") == 'undefined')
		{

			inputLastName.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputLastName.set("v.errors", "");
		}
        if (typeof strUserName == 'undefined')
		{
			inputCmpUserName.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmpUserName.set("v.errors", "");
		}
		if (typeof strUserpassowrd == 'undefined')
		{
			inputCmppassword.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmppassword.set("v.errors", "");
		}
		if (typeof strconfrimPassword == 'undefined')
		{
			inputCmpComfirmPassword.set("v.errors", [
			{
				message: "Please enter value."
			}]);
			isErrorFlag = true;
		}
		else
		{
			inputCmpComfirmPassword.set("v.errors", "");
		}
        if (!isErrorFlag)
		{
			if (strUserpassowrd != strconfrimPassword)
			{
				inputCmppassword.set("v.errors", [
				{
					message: "Password and Confirm Password is not matched."
				}]);
				isErrorFlag = true;
				inputCmppassword.set("v.value", "");
				inputCmpComfirmPassword.set("v.value", "");
			}
		}
         if (!isErrorFlag)
         {
             ///////// Calling apex class method ////
             var action = component.get("c.IsExistingEmail");
             action.setParams(
			{
				strEmail: strUserName
			});
            action.setCallback(this, function(a)
			{
                if (a.getState() === "SUCCESS")
				{
                   	if (a.getReturnValue() != null && a.getReturnValue()!='')
					{
						inputCmpUserName.set("v.errors", [{	message: a.getReturnValue()}]);
					}
                    else
                    {
                       /* var objUserDetail=component.get("v.objUserDetail");
                        objUserDetail={};
                        objUserDetail.username=strUserName;
                        objUserDetail.password=strUserpassowrd;
                        component.set("v.objUserDetail",objUserDetail);*/
                        
                        /////////// Calling an Event ////////////////////
                        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
                       
                        /// set event parameter //////
                        appEvent.setParams({ "NavigateTo" : 1
                                           	  
                                           }
                                          );
                       appEvent.fire();
                        
                        
                    }
                }
                else if (a.getState() === "ERROR")
				{
					
					$A.log("Errors", a.getError());
				}
            });
             $A.enqueueAction(action);
         }
       
        
	}

})