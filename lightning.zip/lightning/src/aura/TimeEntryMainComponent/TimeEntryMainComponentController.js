({
	ViewAccountDetail : function(component, event, helper) {
		var SelectedAccountId = event.getParam("SelectedAccountId");
        
        component.set("v.selectedAccountId",SelectedAccountId);
        
	}
})