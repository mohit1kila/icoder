({
	afterRender  : function(component, helper)
    {
        // After render emit appReady event to report that it's finished
		window.JanssenUI.APP_READY_EVENTS.RENDER_COMPLETE_EVENT.fire();
    }
})