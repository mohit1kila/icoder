({
    init : function(component, event, helper)
    {
        // Set properties in the JanssenUI global
        var RENDER_COMPLETE_EVENT = component.getEvent("AppReady");
        var AMD_LOADED_EVENT = component.getEvent("AppReady");
        if(typeof window.JanssenUI !== "undefined")
        {
            window.JanssenUI.APP_READY_EVENTS = {RENDER_COMPLETE_EVENT : RENDER_COMPLETE_EVENT, AMD_LOADED_EVENT : AMD_LOADED_EVENT};
        }
        else
        {
            window.JanssenUI = {APP_READY_EVENTS : {RENDER_COMPLETE_EVENT : RENDER_COMPLETE_EVENT, AMD_LOADED_EVENT : AMD_LOADED_EVENT}};
        }
    },
	handleAppReady : function(component, event, helper) 
    {
        if(JanssenUI.APP_READY_EVENTS.AMD_LOADED_EVENT.$fired$ && JanssenUI.APP_READY_EVENTS.RENDER_COMPLETE_EVENT.$fired$)
        {
            require(["require", "jquery", "lodash", "angular", "ngAnimate", "ng-fx"], function(require)
            {
                var $ = require("jquery"), _ = require("lodash"), angular = require("angular");
                
                var app = angular.module("providerPortalRegistrationApp", ["ng", "ngAnimate", "ng-fx"]);
                app.controller("providerPortalRegistrationCtrl", ["$scope", function($scope)
                {
                }]);
                
				angular.bootstrap($("#app"), ["providerPortalRegistrationApp"]);
            });
        }
	}
})