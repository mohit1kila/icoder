({
	doInit : function(component, event, helper) {
		var AccID=component.get("v.AccountId");
          if (typeof AccID != 'undefined')
          {
              var action = component.get("c.getAccountById");
              action.setParams({
                  "AccId": AccID
              });
              action.setCallback(this, function(a) {
                  component.set("v.Account", a.getReturnValue());
                  
              });
              $A.enqueueAction(action);
          }
      
	}
})