({
	
    getProviderOptinsList:function(component)
    {
         var action = component.get("c.getProviderForOptIns");
        
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            alert(a.getReturnValue());
            console.log(a.getReturnValue());
            component.set("v.ProviderOptins", a.getReturnValue());
        });
        $A.enqueueAction(action);
    }

})