({
	
    // This method is call by event handler to get the data from another component.
	redirectUser : function(component, event) 
    {
       var StepNo = event.getParam("NavigateTo");
        //alert(StepNo);
        component.set("v.Steps",StepNo);            
	}
})