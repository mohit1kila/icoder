({
showModal : function(component, event, helper) {
   
document.getElementById("backGroundSectionId").style.display = "block";
document.getElementById("newAccountSectionId").style.display = "block";
}
})