({
    init : function(component, event, helper) 
    {
        // Push all instances of all components to the JanssenUI global INSTANCE_STORE
        if(typeof window.JanssenUI !== "undefined")
        {
            // TODO: put an Object check here for JanssenUI.APP_READY_CALLBACKS
            if(window.JanssenUI.INSTANCE_STORE)
            {
                window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
            }
            else
            {
                window.JanssenUI.INSTANCE_STORE = {};
                window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
            }
        }
        else
        {
            window.JanssenUI = {INSTANCE_STORE : {}};
            window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] = {component:window.$A.getCmp(component.$concreteComponentId$), helper:helper};
        }
        
        component.set("v.loadAppScript", false);
        var appReady = component.get("v.AppReady");
        var pushToAppReadyQuene;
        if(typeof appReady === "string" && appReady)
        {
            pushToAppReadyQuene = function()
            {
                component.set("v.loadAppScript", true);
            };         
        }
        else if(typeof appReady === "object" && appReady.$meth$ && typeof appReady.$meth$ === "function")
        {
            pushToAppReadyQuene = appReady.$meth$; 
        }
        
        if(pushToAppReadyQuene) // By now pushToAppReadyQuene will be a function or undefined 
        {
            // Push AppReady callbacks
            if(typeof window.JanssenUI !== "undefined")
            {
                // TODO: put an Array check here for JanssenUI.APP_READY_CALLBACKS
                if(window.JanssenUI.APP_READY_CALLBACKS)
                {
                    window.JanssenUI.APP_READY_CALLBACKS.push(function(){pushToAppReadyQuene(helper.getFormattedGlobalId(component), component, helper);});
                }
                else
                {
                    window.JanssenUI.APP_READY_CALLBACKS = [function(){pushToAppReadyQuene(helper.getFormattedGlobalId(component), component, helper);}];
                }
            }
            else
            {
                window.JanssenUI = {APP_READY_CALLBACKS : [function(){pushToAppReadyQuene(helper.getFormattedGlobalId(component), component, helper);}]};
            }
        }
    }
})