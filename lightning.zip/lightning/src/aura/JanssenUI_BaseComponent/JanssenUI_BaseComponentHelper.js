({
    getFormattedGlobalId : function(component) 
    {
        return "GID_"+component.get("globalId").replace(/[:;]/g, "_");
    },
    registerComponentModule : function(moduleName, dependencies, definitionFunction)
    {
        var moduleRegisterFunction = function()
        {
            window.define && window.define(moduleName, dependencies, definitionFunction);
        }
        
        // Push module definitions to COMPONENT_MODULES
        if(typeof window.JanssenUI !== "undefined")
        {
            // TODO: put an Object check here for JanssenUI.COMPONENT_MODULES
            if(window.JanssenUI.COMPONENT_MODULES)
            {
                window.JanssenUI.COMPONENT_MODULES[moduleName] = moduleRegisterFunction;
            }
            else
            {
                window.JanssenUI.COMPONENT_MODULES = {};
                window.JanssenUI.COMPONENT_MODULES[moduleName] = moduleRegisterFunction;
            }
        }
        else
        {
            window.JanssenUI = {COMPONENT_MODULES : {}};
            window.JanssenUI.COMPONENT_MODULES[moduleName] = moduleRegisterFunction;
        }
    },
    // Push the instance of the component's helper to the JanssenUI global INSTANCE_STORE
    // Not calling this will default to the super component's helper
    registerHelper : function(component, helper)
    {
        if(typeof window.JanssenUI !== "undefined" && window.JanssenUI.INSTANCE_STORE && window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)] && (window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)].helper !== helper))
        {
            window.JanssenUI.INSTANCE_STORE[helper.getFormattedGlobalId(component)].helper = helper;
        }
    }
})