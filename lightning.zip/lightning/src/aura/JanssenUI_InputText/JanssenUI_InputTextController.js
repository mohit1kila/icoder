// All functions called on AppReady will have formattedGlobalId, component, helper passed to it as parameters
// All modules that extend c:JanssenUI_BaseComponent inherits this behavior.
({
    setAngularModule : function(component, event, helper) 
    {
        // Push the instance of the component's helper to the JanssenUI global INSTANCE_STORE
        // Not calling this will default to the super component's helper
        helper.registerHelper(component, helper);
        helper.registerComponentModule("janssenUI_InputText", ["require", "jquery", "lodash", "angular"], function(require)
        {
            var $ = require("jquery");
            var _ = require("lodash");
            // Yes the first letter of the module name MUST be lowercase or else it won't inject as a dependency
        	var app = angular.module("janssenUI_InputText", ["ng"]);
        	app.directive("janssenuiInputtext", function() 
            {
        		return {
        			restrict: "A",
                    scope : true,
                    compile: function(tElement, attributes) 
                    {
      					//do optional DOM transformation here
      					var GID = "GID_"+ attributes["janssenuiInputtext"].replace(/[:;]/g, "_");
                        
                        //$(tElement).append("{{GID}} | {{fromCtrl | json}}"); 
      					return function(scope, element, attributes) 
                        {
                            // overrides from controller
                            //scope.fromCtrl = "xxx";
        					//linking function here
							scope.GID = GID;

                            // Dig into the $parent scopes until a property with the name variable is found until root scope
                            var operatingScope = scope;
                            var variable = window.JanssenUI.INSTANCE_STORE[GID].component.get("v.variable");
                            var indices = [];
                            
                            if(variable)
                            {
                                do
                                {
                                    if(operatingScope.hasOwnProperty(variable))
                                    {
                                        if(indices.length > 0)
                                        {
                                            var temp;
                                            if(!Array.isArray(operatingScope[variable]))
                                            {
                                                temp = {value : operatingScope[variable], scopeId : scope.$id};
                                                operatingScope[variable] = [];
                                            }
                                            else
                                            {
                                                temp = {value : _.get(operatingScope[variable],"["+_.map(new Array(indices.length), function(){return 0;}).join("][")+"].value"), scopeId : scope.$id};
                                            }
                                            _.update(operatingScope[variable], "["+_.reverse(indices).join("][")+"]", function(){return temp;});
                                        }
                                        else
                                        {
                                            operatingScope[variable] = {value : operatingScope[variable], scopeId : scope.$id};
                                        }
                                        break;
                                    }
									else
                                    {
                                        if(operatingScope.$parent.hasOwnProperty("$index")){indices.push(operatingScope.$parent.$index);}
                                        operatingScope = operatingScope.$parent;
                                    }
                                }
                                while(operatingScope.$id > 1);
                            }
      					};
    				}
        		};
        	});
        });        
    }
})