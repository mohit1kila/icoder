({
    // Your renderer method overrides go here
    render: function (component, helper) 
    {
        var render = this.superRender();
        
        var afterRenderFunctionToBeRegistered = function()
        {
            // Decorate with the unique global ID
            //var formattedGlobalId = helper.getFormattedGlobalId(component);
            var variable = component.get("v.variable");
            
            // Iterating because IE8 and lower behaves differently when text nodes are involved,
            // 	therefore, firstChild and lastChild are unstable options
            for(var inc=0,len=render[0].children.length; inc<len; inc++)
            {
                // for IE8 or lower nodeName will show as "!" rather than "#comment" for comment nodes
                if(render[0].children[inc].nodeName.toUpperCase() === "DIV")
                {
                    for(var inc2=0,len2=render[0].children[inc].children.length; inc2<len2; inc2++)
                    {
                        if(render[0].children[inc].children[inc2].nodeName.toUpperCase() === "INPUT")
                        {
                            // for IE7 and lower setAttribute on events will break and doesn't work for styles
                            var ngRepeatIndicies = "[$parent.$parent.$parent.$index][$parent.$index]";
                            var operatingElement = render[0].children[inc].children[inc2];
                            var directiveMap = [];
                            var count = 0;
                            do
                            {
                                operatingElement = operatingElement.parentNode;
                                var operatingAttr = operatingElement.getAttribute('data-ng-repeat') ? true : 
                                (operatingElement.getAttribute('data-ng-switch') || operatingElement.getAttribute('data-ng-if') || operatingElement.getAttribute('data-ng-controller') /*|| more child scoping directives */? false : null);
                                if(typeof operatingAttr === "boolean")
                                {
                                    if(operatingAttr)
                                    {
                                        if(directiveMap[count]){directiveMap[count] += ".$parent.$index";}else{directiveMap[count] = "$parent.$index";}
                                        count++;
                                    }
                                    else
                                    {
                                        if(directiveMap[count]){directiveMap[count] += ".$parent";}else{directiveMap[count] = "$parent";}
                                    }
                                }
                            }while(operatingElement.getAttribute('id')  !== "app");
                            
                            debugger;
                            //variable && render[0].children[inc].children[inc2].setAttribute("data-ng-model", variable+ngRepeatIndicies+".value");
                            variable && render[0].children[inc].children[inc2].setAttribute("data-ng-model", variable+ngRepeatIndicies+".value");
                            break;
                        }
                    }
                    break;
                }
            }
        };
        
        if(window.JanssenUI !== "undefined")
        {
            if(window.JanssenUI.AFTER_RENDER_STORE && Array.isArray(window.JanssenUI.AFTER_RENDER_STORE))
            {
                window.JanssenUI.AFTER_RENDER_STORE.push(afterRenderFunctionToBeRegistered);
            }
            else
            {
                window.JanssenUI.AFTER_RENDER_STORE = [afterRenderFunctionToBeRegistered];
            }
        }
        else
        {
            window.JanssenUI = {AFTER_RENDER_STORE : [afterRenderFunctionToBeRegistered]};
        }
        
        return render;
    },
    afterRender : function(component, helper)
    {
        
    }
})