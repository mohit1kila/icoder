({
	doInit : function(component, event, helper) 
    { 
       var action = component.get("c.getRelationList");

    
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.RelationshipItem", a.getReturnValue());
            
            var cid= component.find("Caregiver");
            alert(cid);
            $A.util.addClass(cid, "slds-active");
            
        });
        $A.enqueueAction(action);
       helper.getGenderData(component);
	},
    NavigateToPatientInfo : function(component, event, helper)
    {
        
        //Calling Event : 
        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
        
        /// set event parameter //////
        appEvent.setParams({ "NavigateTo" : 4
                            
                           }
                          );
        appEvent.fire();
    }
    
    

})