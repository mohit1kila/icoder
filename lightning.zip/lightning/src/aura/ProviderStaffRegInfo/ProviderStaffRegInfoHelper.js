({
  
    setFieldValues:function(component)
    {
        
        var objUserDetail=component.get("v.objUserDetail");
        var input_firstName = component.find("firstName");
        var input_MiddleInitial = component.find("MiddleInitial");
        var input_LastName = component.find("LastName");
        var input_Suffix = component.find("Suffix");
        var input_PrimaryPhone = component.find("PrimaryPhone");
        var input_SecondaryPhone = component.find("SecondaryPhone");
        
         
        objUserDetail.personalFirstName=input_firstName.get("v.value");
        objUserDetail.personalLastName=input_LastName.get("v.value");
        objUserDetail.personalMiddleName=input_MiddleInitial.get("v.value");
        objUserDetail.personalSurfix=input_Suffix.get("v.value");
        objUserDetail.personalprimaryPhone=input_PrimaryPhone.get("v.value");
        objUserDetail.personalSecondaryPhone=input_SecondaryPhone.get("v.value");
        //alert('setFieldValues 14');
        component.set("v.objUserDetail",objUserDetail);        
        
        
        
    }
})