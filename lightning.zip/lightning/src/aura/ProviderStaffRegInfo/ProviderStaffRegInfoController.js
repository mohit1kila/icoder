({
    doInit : function(component, event, helper) 
    {
        var objUserDetail=component.get("v.objUserDetail");
        component.set("v.objUserDetail",objUserDetail);
        var isPRovider=objUserDetail['isProvider'];
        if(isPRovider)
        {
            component.set("v.TopHeading",'Provider');
        }
        else
        {
            component.set("v.TopHeading",'Office Staff');
        }
        component.set("v.isPRovider",isPRovider);
        
    },
    
    NextButton:function(component, event, helper)
    {
        //alert('heelo');
        helper.setFieldValues(component);
        //alert('heelo-->');
        var objUserDetail=component.get("v.objUserDetail");
        
        var appEvent = $A.get("e.c:ProviderRegEvent");
        appEvent.setParams({ "StepNo" : 3,
                            "objUserDetail" : objUserDetail
                           }
                          );
        appEvent.fire();
        
    },
    PreviousButton:function(component, event, helper)
    {
        helper.setFieldValues(component);
        var objUserDetail=component.get("v.objUserDetail");
        var appEvent = $A.get("e.c:ProviderRegEvent");
        appEvent.setParams({ "StepNo" : 1,
                            "objUserDetail" : objUserDetail
                           }
                          );
        appEvent.fire();
        
    }
})