({
	render: function(component, helper) 
    {
        var nestedElements = component.superRender();
        
        // Get attributes from the component markup
       	var x = component.get("v.posX");
        var y = component.get("v.posY");
        var fill = component.get("v.fill");
        var style = component.get("v.style");
        
        // Create and return SVG circle element
        var text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        x && text.setAttribute("x", x);
        y && text.setAttribute("y", y);
        fill && text.setAttribute("fill", fill);
        //FIXME: This WILL break in IE, uses classes and CSS stylesheets as a workaround 
        style && text.setAttribute("style", style);
        for(var inc=0,len=nestedElements.length; inc<len; inc++)
        {
            text.appendChild(nestedElements[inc]);
        }
        return text;
    }
})