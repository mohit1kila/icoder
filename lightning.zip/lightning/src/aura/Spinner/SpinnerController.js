({
	changeHandler : function(component, event, helper) {
		helper.showHideSpinner(component); 
	}
})