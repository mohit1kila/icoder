({
	doInit : function(component, event, helper) {
        //Calling Method to Get Menu 
        var action = component.get("c.getHeaderList");
        
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.HeaderItem", a.getReturnValue());
           var selected= component.get("v.SelectedItem");
            //var comp= component.find('Provider');
           
            //alert( document.getElementById("Provider"));
            //$A.util.addClass(selected,"slds-active");
        });
        $A.enqueueAction(action);
		
	}
})