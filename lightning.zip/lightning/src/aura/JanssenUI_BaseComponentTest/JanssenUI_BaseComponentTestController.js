({
    init : function(component, event, helper) 
    {
        //console.log("init from JanssenUI_BaseComponentTest");
    },
    myCustomAction : function(component, event, helper)
    {
        console.log("myCustomAction overwrite");
    }
})