({
	    
    doInit : function(component, event) {
        var action = component.get("c.findAllAccount");
        action.setCallback(this, function(a) {
            component.set("v.ListSize", a.getReturnValue().length);
            component.set("v.Accounts", a.getReturnValue());
           
        });
        $A.enqueueAction(action);
    },
    searchKeyChange: function(component, event) {
    var searchKey = event.getParam("searchKey");
       
    var action = component.get("c.findByNameAccount");
    action.setParams({
      "searchKey": searchKey
    });
    action.setCallback(this, function(a) {
        component.set("v.Accounts", a.getReturnValue());
        component.set("v.ListSize", a.getReturnValue().length);
    });
    $A.enqueueAction(action);
},
    getAccountDetail : function(cmp, event, helper) {
        var idx = event.target.id;
         var myEvent = $A.get("e.c:TimeEntryViewAccountEvent");
        myEvent.setParams({"SelectedAccountId": idx});
        myEvent.fire();
        
    }

})