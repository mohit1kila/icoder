({
    doInit : function(component, event, helper) 
    {    
        //Calling helper Method
        helper.getDeliveryOptinsList(component);
        helper.getDocumentOptinsList(component);
        var objUserDetail=component.get("v.objUserDetail");
        component.get("v.objUserDetail",objUserDetail);
    },
    
    CreateProvider : function(component, event, helper) 
    {    
        var objUserDetail=component.get("v.objUserDetail");
        var jsonText1 = JSON.stringify(objUserDetail);
        var action = component.get("c.registerprovider");
        action.setParams({objUser: jsonText1});
        action.setCallback(this, function(a)
        {
        	if (a.getState() === "SUCCESS")
            {
            	//alert(a.getState());
            }
            else if (a.getState() === "ERROR")
			{
            	//alert('error occurred'+a.getError());
                var jsonText = JSON.stringify(a.getError());
                //alert(jsonText);
                $A.log("Errors", a.getError());
			}
		});
        $A.enqueueAction(action);
    }
})