({
    registerHelper : function(component, event, helper) 
    {
    	// Push the instance of the component's helper to the JanssenUI global INSTANCE_STORE
    	// If this is not used, it'll default the super component's helper
        helper.registerHelper(component, helper);
	},
    // Parameters component, event, helper are not passed to AppReady event handlers
    // Use JanssenUI.INSTANCE_STORE to get this instance of the current component and it's helper (will default to super component's helper if helper.registerHelper is not called on the init event)
	run : function()
    {   
        // ensure the angular module store is executed before using JanssenUI_AngularModule
		require(["require", "jquery", "lodash", "angular"].concat(Object.keys(window.JanssenUI.COMPONENT_MODULES || [])), function(require)
        {
            var $ = require("jquery");
            var _ = require("lodash");
            var angular = require("angular");
            
            var app = angular.module("app", ["ng"].concat(Object.keys(window.JanssenUI.COMPONENT_MODULES || [])));
            app.controller("ctrl2", [function(){}]);
            app.controller("ctrl", ["$scope", "$sce", function($scope, $sce)
			{
                // TODO: Consider turning data-gid into a directive
                var thisGID = "GID_" + $("#app").attr("data-gid").replace(/[:;]/g, "_");
                $scope.GID = thisGID;
                
                var getScopeById = function(id)
                {
                    var scopedElements = $(".ng-scope");
                    for(var inc=0,len=scopedElements.length; inc<len; inc++)
                    {
                        var scope = angular.element(scopedElements[inc]).scope();
                        if(scope.$id === id){return scope;}
                    }
                }
                var executeLightningFunction = function(GID, fName, args)
                {
                    var functionLookup = fName.split(".");
                    if(functionLookup[0] === "c")
                    {
                        // event parameter is set to undefined as to maintain consistency in passed parameters if the controller function is ever used for events
                        return window.JanssenUI.INSTANCE_STORE[GID].component.get(fName).$meth$.apply(this, [window.JanssenUI.INSTANCE_STORE[GID].component, undefined, window.JanssenUI.INSTANCE_STORE[GID].helper].concat(args));
                    }
                    else if(functionLookup[0] === "h")
                    {
                        return window.JanssenUI.INSTANCE_STORE[GID].helper[functionLookup[1]].apply(this, [window.JanssenUI.INSTANCE_STORE[GID].component, window.JanssenUI.INSTANCE_STORE[GID].helper].concat(args));
                    }
                }
                
				//$scope.fromCtrl = "fromCtrl";
                $scope.submit = function(GID, clientSideValidations, serverSideValidations, onSuccess)
                {
                    var isAtLeastOnError = false;
                    var variablesToSend = {};
                    if(clientSideValidations)
                    {
                        for(var prop in clientSideValidations)
                        {
                            variablesToSend[prop] = $scope[prop].value;
                            if(clientSideValidations.hasOwnProperty(prop))
                            {
                                var scope = getScopeById($scope[prop].scopeId);
                                var errorMsgs = [];
                                for(var inc=0,len=clientSideValidations[prop].length; inc<len; inc++)
                                {
                                    var errorMsg = executeLightningFunction(GID, clientSideValidations[prop][inc], $scope[prop].value);
                                    errorMsg && errorMsgs.push(_.escape(errorMsg));
                                }
                                if(scope.required && !$scope[prop].value)
                                {
                                    errorMsgs.push("This field is required.");
                                }
                                if(errorMsgs.length)
                                {
                                    scope.errorMsg = $sce.trustAsHtml(errorMsgs.join("<br>"));
                                    scope.error = true; isAtLeastOnError = isAtLeastOnError || true;
                                }
                                else
                                {
                                    scope.errorMsg = "";
                                    scope.error = false; isAtLeastOnError = isAtLeastOnError || false;
                                }
                            }
                        }
                    }
                    if(!isAtLeastOnError)
                    {
                        executeLightningFunction(GID, onSuccess, [variablesToSend]);
                    }
                    
                    //console.log(GID, clientSideValidations, serverSideValidations, onSuccess);
                }
            }]);
                        
            angular.bootstrap($("#app"), ["app"]);
        });
	},
    testControllerFunction : function(component, event, helper)
    {
        console.log("testControllerFunction called:", component, event, helper);
    },
    validateVariable1 : function(component, event, helper, variable)
    {
        console.log("validateVariable1", variable);
        return "";
    },
    validateVariable2a : function(component, event, helper, variable)
    {
        console.log("validateVariable2a", variable);
        return "";
    },
    validateVariable2b : function(component, event, helper, variable)
    {
        console.log("validateVariable2b", variable);
        return "";
    },
    next : function(component, event, helper, variablesToSend)
    {
        console.log(variablesToSend);
    },
    serverSideValidation : function(component, event, helper, variablesToSend)
    {
        
    }
})