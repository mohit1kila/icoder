({
	testHelperFunction : function(component, helper) 
    {
		console.log("testHelperFunction called:", component, helper);
	},
    testControllerFunction : function(component, event, helper)
    {
        console.log("testControllerFunction called:", component, event, helper);
    },
    validateVariable1 : function(component, /*event,*/ helper, variable)
    {
        console.log("validateVariable1", variable);
        return "tttt";
    },
    validateVariable2a : function(component, /*event,*/ helper, variable)
    {
        console.log("validateVariable2a", variable);
        return "";
    },
    validateVariable2b : function(component, /*event,*/ helper, variable)
    {
        console.log("validateVariable2b", variable);
        return "";
    },
    next : function(component, /*event,*/ helper, variablesToSend)
    {
        console.log(variablesToSend);
    }
})