({
    /**
     * Intented to be a (mostly) drop in replacement for ltng:require
     * 
     * Fixes an issue in ltng:require where multiple calls to the same resouce will continually
     * append the same resource to the DOM, thus causing memory leaks, bandwidth (critial for mobile devices),
     * and potentially exposing the application to XSS attacks (and CSRF under certain conditions).
     * 
     * The JavaScript code for this function should be compatable with IE5.5, but uses modern features if available.
     */
    init : function(component, event, helper) 
    {
        // Collected from DOM
        var styleElements;
        var scriptElements;
        if(document.querySelectorAll)
        {
            styleElements = document.querySelectorAll("link[rel=stylesheet][href]");
            scriptElements = document.querySelectorAll("script[src]");
        }
        else
        {
            var styleElements = [];
            var scriptElements = [];
            
            var allStylesheets = document.getElementsByTagName('LINK');
            for (var inc=0,len=allStylesheets.length;inc<len;inc++)
            {
                if(allStylesheets[inc].getAttribute("rel") === "stylesheet" && allStylesheets[inc].getAttribute("href") !== null){styleElements.push(allStylesheets[inc]);}
            }
            var allScripts = document.getElementsByTagName('SCRIPT');
            for (var inc=0,len=allScripts.length;inc<len;inc++)
            {
                if(allScripts[inc].getAttribute("src") !== null){scriptElements.push(allScripts[inc]);}
            }
        }
        
        // From attributes
        var styles = component.get("v.styles") && component.get("v.styles").split(/\s+/) || [];
        var scripts = component.get("v.scripts") && component.get("v.scripts").split(/\s+/) || [];
        
        for(var inc=0,len=styles.length; inc<len; inc++)
        {
            var notAppended = true;
            for(var inc2=0,len2=styleElements.length; inc2<len2; inc2++)
            {
                notAppended = notAppended && styles[inc] !== styleElements[inc2].getAttribute("href");
                if(!notAppended){break;} // It's already appended not need to continue
            }
            if(notAppended)
            {
                var elementToAppend = document.createElement('LINK');
                elementToAppend.setAttribute("rel","stylesheet");
                elementToAppend.setAttribute("href",styles[inc]);
                document.getElementsByTagName("head")[0].appendChild(elementToAppend);
            }
        }
        
        for(var inc=0,len=scripts.length; inc<len; inc++)
        {
            var notAppended = true;
            for(var inc2=0,len2=scriptElements.length; inc2<len2; inc2++)
            {
                notAppended = notAppended && scripts[inc] !== scriptElements[inc2].getAttribute("src");
                if(!notAppended){break;} // It's already appended not need to continue
            }
            if(notAppended)
            {
                var elementToAppend = document.createElement('SCRIPT');
                elementToAppend.setAttribute("type","text/javascript");
                elementToAppend.setAttribute("src",scripts[inc]);
                document.getElementsByTagName("head")[0].appendChild(elementToAppend);
            }
        }
    }
})