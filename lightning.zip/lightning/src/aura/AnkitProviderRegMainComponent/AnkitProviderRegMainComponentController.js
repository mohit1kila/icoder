({
	redirectUser : function(component, event) 
    {
        var stepname= event.getParam("stepTOMove");
        alert(stepname);
        var WrapperData= event.getParam("objUserDetail");
        
        component.set("v.objUserDetail",WrapperData);
        component.set("v.steps",stepname);
        
            
	}
})