({
    doInit : function(component, event, helper) {
       
        var action = component.get("c.getProduct");//Fetching Map from Controller
        
        action.setCallback(this, function(a) {
            var accs=a.getReturnValue();
            //component.set("v.myProdMap", a.getReturnValue());//Set return value to Contact Map
            var MyProd = component.get("v.myProdMap");//Getting Map and Its value
               //alert(MyProd);      
            var tile='<ul class="slds-list--vertical slds-has-cards">';
             
                var wrappers=new Array();
                for (var idx=0; idx<accs.length; idx++) {
                    
                    var wrapper = { 'lstprod' : accs[idx].lstprod,
                                    'ProductFamily' : accs[idx].ProductFamily
                                            };
                     wrappers.push(wrapper);
                }
component.set('v.Prodlist', wrappers);
            
           /* for (key in MyProd){
                
          
                tile +='<li class="slds-list__item><div class="slds-tile slds-tile--board"><div class="slds-tile__detail"><p class="slds-text-heading--medium">'+key+'</p></div></div></li><ul class="slds-list--vertical slds-has-cards">';
                var  tile1='';
               for(var x in MyProd[key])
               {
                   
                tile1 += '<li class="slds-list__item">';
                tile1 += '<div class="slds-tile slds-tile--board">';
                tile1 += '<div class="slds-tile__detail">';
                tile1 += '<p class="slds-text-heading--medium">'+ MyProd[key][x].strProdnAME +'</p>';
                tile1 += '<p class="slds-truncate">'+ MyProd[key][x].strProdId +'</p>';
                tile1 += '<p class="slds-truncate">'+ ''+'</p>';
                tile1 += '</div>';
                tile1 += '</div>';
                tile1 += '</li>';
                }
                tile1=tile1+'</ul>';
            }
            tile = tile+tile1+'</ul>';
            alert(tile);
            document.getElementById("contactDetail").innerHTML = tile; */           
        });
        $A.enqueueAction(action);
    },
    
    NavigateToContactOptins : function(component, event, helper) {
        //Calling Event : Navigate to Optins
        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
        
        /// set event parameter //////
        appEvent.setParams({ 
                            "NavigateTo" : 3
                           }
                          );
        appEvent.fire();
    }
    
})