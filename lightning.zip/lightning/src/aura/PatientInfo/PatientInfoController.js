({
	NavigateToMedicalIns : function(component, event, helper) {
         //Calling Event : Navigate to Optins
        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
        
        /// set event parameter //////
        appEvent.setParams({ 
            				"NavigateTo" : 6
                           }
                          );
        appEvent.fire();
		
	}
})