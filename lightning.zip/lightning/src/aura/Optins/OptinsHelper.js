({
	getDeliveryOptinsList:function(component)
    {
         var action = component.get("c.getDeliveryOptins");
        
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.DeliveryOptins", a.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    getDocumentOptinsList:function(component)
    {
         var action = component.get("c.getDocumentDelivery");
        
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.DocumentOptins", a.getReturnValue());
        });
        $A.enqueueAction(action);
    }
})