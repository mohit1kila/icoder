({
	createProvider : function(component, event, helper) {
		var appEvent = $A.get("e.c:ankitProviderEvent");
                        appEvent.setParams({ "stepTOMove" : "ProviderRegistration",
                                           	  "objUserDetail" : objUserDetail
                                           }
                                          );
                       
                        appEvent.fire();
	}
})