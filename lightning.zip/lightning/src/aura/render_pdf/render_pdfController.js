({
    renderPDF : function(component, event, helper) 
    {
        window.count = window.count || 0;
        count++;
        
        console.log("render PDF");
        var doc = new jsPDF('p', 'pt', 'letter');
        var elem = $("#target")[0];
        var specialElementHandlers = {
            '#editor': function(element, renderer)
            {
                return true;
            }
        };
        doc.fromHTML(elem, 80, 60, {
            'width': 522,
            'elementHandlers': specialElementHandlers
        });
        doc.text(10, 25, "You have rendered this HTML as a PDF "+count+" times");
        var data = doc.output("datauristring");
        console.log(data);
        
        //-------------------------------------------------------------------------------------------------------------------------------------
        var pdfData = Base64.decode(data.substr(28));
        PDFJS.disableWorker = true;
        PDFJS.getDocument({data: pdfData, worker : false}).then(function(pdf)
                                                                {
                                                                    // Fetch the first page.
                                                                    pdf.getPage(1).then(function (page)
                                                                                        {
                                                                                            var scale = 1;
                                                                                            var viewport = page.getViewport(scale);
                                                                                            // Prepare canvas using PDF page dimensions.
                                                                                            var canvas = $('#the-canvas')[0];
                                                                                            var context = canvas.getContext('2d');
                                                                                            canvas.height = viewport.height;
                                                                                            canvas.width = viewport.width;
                                                                                            // Render PDF page into canvas context.
                                                                                            var renderContext = {
                                                                                                canvasContext: context,
                                                                                                viewport: viewport
                                                                                            };
                                                                                            page.render(renderContext);
                                                                                        });
                                                                });
        
    },
    downloadPDF : function(component, event, helper) 
    {
        window.count = window.count || 0;
        count++;
        
        console.log("render PDF");
        var doc = new jsPDF('p', 'pt', 'letter');
        var elem = $("#target")[0];
        var specialElementHandlers = {
            '#editor': function(element, renderer)
            {
                return true;
            }
        };
        doc.fromHTML(elem, 80, 60, {
            'width': 522,
            'elementHandlers': specialElementHandlers
        });
        doc.text(10, 25, "You have rendered this HTML as a PDF "+count+" times");
        var data = doc.save();
    }
})