({
	
    doInit : function(component, event, helper) 
    { 
        
        
       
	},
    mydata : function(component, event, helper) 
    {
    var getAccountId=component.get("v.AccountId");
       var action = component.get("c.getTimeEntryList");
       action.setParams({
          "AccountId": getAccountId
        }); 
    
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.TimeEntryList", a.getReturnValue());
            
            
           
            //$A.util.addClass(cid, "slds-active");
            
        });
        $A.enqueueAction(action);
     }
})