({
	ToggleClass : function(component, event, helper) {
         var dataValue = event.target.value;
        if(dataValue == 'patient')
        {
            var toggleText = component.find("dvPatient");
			$A.util.addClass(toggleText, "ON");
        	var toggleText = component.find("dvCaregiver");
			$A.util.removeClass(toggleText, "ON");
        }
        else if (dataValue == 'caregiver')
        {
            var toggleText = component.find("dvPatient");
            $A.util.removeClass(toggleText, "ON");
            var toggleText = component.find("dvCaregiver");
            $A.util.addClass(toggleText, "ON");
        }
       
	},
    NavigateToProvider :function(component, event, helper) 
    {
        //Calling Event : Navigate to Optins
        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
        
        /// set event parameter //////
        appEvent.setParams({ 
            				"NavigateTo" : 2
                           }
                          );
        appEvent.fire();
    }
    
})