({
	toggleSpinners : function(component, event, helper) {
		component.set('v.showSpinner', !component.get('v.showSpinner'));
	}
})