({
    GoToProvider : function(component, event, helper) {
        alert('Mohit');
		var appEvent = $A.get("e.c:ankitProviderEvent");
         alert(appEvent);
         appEvent.setParams({ "stepTOMove" : "ProviderRegistration"
                                           	  
                                           }
                                          );
                       alert('>>'+appEvent);
                        appEvent.fire();
      
	},
	AssignVal : function(component, event, helper) {
        alert('Mohit');
		var cc = component.getConcreteComponent();
        
        component.set("v.objUserDetail.isProvider", "True");
        alert(component.get("v.objUserDetail.isProvider"));
	},
     toggle : function(component, event, helper) {
         alert('mohit');
        var toggleText = component.find("text");
        $A.util.toggleClass(toggleText, "toggle");
    },
    showhid : function(component, event, helper) 
    {
         
         var PrescribeImage = component.find("PresDiv2");
         var PrescribeText = component.find("PresDiv");
        $A.util.addClass(PrescribeImage, "slds-show");
        $A.util.addClass(PrescribeText, "slds-hide");
        
         var OfficeStafText = component.find("OfficeStaffOn");
         var OfficeStafImage = component.find("OfficeStaffOF");
        //$A.util.addClass(OfficeStafText, "slds-show");
       // $A.util.addClass(OfficeStafImage, "slds-hide");
       // $A.util.addClass(OfficeStafText, "slds-show");
    },
    showhideStaff : function(component, event, helper) {
        
         var OfficeStaffImage = component.find("OfficeStaffOn");
         var OfficeStaffOf = component.find("OfficeStaffOF");
        var PrescribeImage = component.find("PresDiv2");
         var PrescribeText = component.find("PresDiv");
        $A.util.addClass(OfficeStaffOf, "slds-show");
        $A.util.addClass(OfficeStaffImage, "slds-hide");
        /*$A.util.addClass(PrescribeText, "slds-show");
        $A.util.removeClass(PrescribeText, "slds-hide");
        $A.util.addClass(PrescribeImage, "slds-hide");
        $A.util.removeClass(PrescribeImage, "slds-show");*/
    }
    
})