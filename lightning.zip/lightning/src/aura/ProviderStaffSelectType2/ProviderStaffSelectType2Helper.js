({
	DisplaysetProvider: function(component, event, helper)
    {
        var ProviderOnimageComponent=component.find("Provider_OnImage");
        var ProviderOffComponent=component.find("Provider_OffImage");
        var OfficeStaffOnimageComponent=component.find("OfficeStaff_OnImage");
        var OfficeStaffOffComponent=component.find("OfficeStaff_OffImage");
        
        //////////////////// Provider Image  //////////////////////////////
        $A.util.removeClass(ProviderOnimageComponent, "slds-hide");
        $A.util.removeClass(ProviderOffComponent, "slds-show");
        $A.util.addClass(ProviderOnimageComponent, "slds-show");
        $A.util.addClass(ProviderOffComponent, "slds-hide");
        
        ///// Office Staff Attribute ///////////////////////////
        $A.util.removeClass(OfficeStaffOnimageComponent, "slds-show");
        $A.util.removeClass(OfficeStaffOffComponent, "slds-hide");
        $A.util.addClass(OfficeStaffOnimageComponent, "slds-hide");
        $A.util.addClass(OfficeStaffOffComponent, "slds-show");
        
    },
    
    DisplayOfficeSetStaff:function(component, event, helper)
    {
        var ProviderOnimageComponent=component.find("Provider_OnImage");
        var ProviderOffComponent=component.find("Provider_OffImage");
        var OfficeStaffOnimageComponent=component.find("OfficeStaff_OnImage");
        var OfficeStaffOffComponent=component.find("OfficeStaff_OffImage");
        
        //////////////////// Provider Image  //////////////////////////////
        $A.util.removeClass(ProviderOnimageComponent, "slds-show");
        $A.util.removeClass(ProviderOffComponent, "slds-hide");
        $A.util.addClass(ProviderOnimageComponent, "slds-hide");
        $A.util.addClass(ProviderOffComponent, "slds-show");
        
        ///// Office Staff Attribute ///////////////////////////
        $A.util.removeClass(OfficeStaffOnimageComponent, "slds-hide");
        $A.util.removeClass(OfficeStaffOffComponent, "slds-show");
        $A.util.addClass(OfficeStaffOnimageComponent, "slds-show");
        $A.util.addClass(OfficeStaffOffComponent, "slds-hide");
    }

})