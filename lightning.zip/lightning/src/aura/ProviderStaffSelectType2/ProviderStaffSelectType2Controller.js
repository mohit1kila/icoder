({
    doInit : function(component, event, helper) 
    {
        var objUserDetail=component.get("v.objUserDetail");
        if(objUserDetail != null)
        {
            if(objUserDetail.isProvider==null) {objUserDetail.isProvider=true;}
            if(objUserDetail.isProvider){helper.DisplaysetProvider(component, event, helper);}else{helper.DisplayOfficeSetStaff(component, event, helper);}
            component.get("v.objUserDetail",objUserDetail);
        }
        else
        {
            objUserDetail = {};
            objUserDetail.isProvider=true;
            helper.DisplaysetProvider(component, event, helper);
        }
        component.get("v.objUserDetail",objUserDetail);
    },
    
    DisplayProvider: function(component, event, helper)
    {
        helper.DisplaysetProvider(component, event, helper);
        var objUserDetail = component.get("v.objUserDetail");
        objUserDetail.isProvider=true;
        component.get("v.objUserDetail",objUserDetail);
    },
    
    DisplayOfficeStaff:function(component, event, helper)
    {
        helper.DisplayOfficeSetStaff(component, event, helper);
        var objUserDetail = component.get("v.objUserDetail");
        objUserDetail.isProvider=false;
        component.get("v.objUserDetail",objUserDetail);
    },
    
    NextButton:function(component, event, helper)
    {
        var objUserDetail = component.get("v.objUserDetail");
        //alert('office staff next button' + objUserDetail);
        var appEvent = $A.get("e.c:ProviderRegEvent");
        appEvent.setParams({ "StepNo" : 2,"objUserDetail" : objUserDetail});
        appEvent.fire();
    }
})