({
	doInit : function(component, event, helper) {
          var getProciderType= component.get("v.ProviderType");
		helper.getMenuList(component,getProciderType);
        var objUserDetail=component.get("v.objUserDetail");
       // alert(json.stringfy(objUserDetail));
       
        alert('doInit menu'+objUserDetail);
       for(var x in objUserDetail)
        {
            alert('x-->'+x+' '+objUserDetail[x]);
        }
       
        
       
	},
    SetvaluesForWrapper : function(component, event) 
    {       
        var WrapperData= event.getParam("objWrapperUserDetail");
        alert("SetvaluesForWrapper-->"+WrapperData);
        component.set("v.objUserDetail",WrapperData);
         alert('in menu do init');
        alert('in menu do init'+WrapperData);
        for(var x in WrapperData)
        {
            alert('x-->'+x+' '+WrapperData[x]);
        }
    }
})