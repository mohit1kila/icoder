({
    getMenuList:function(component,providerType)
    {
         var action = component.get("c.getMenuList");
        action.setParams({
          "isProvider": false
        });
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            console.log(a.getReturnValue());
            component.set("v.MenuItems", a.getReturnValue());
        });
        $A.enqueueAction(action);
    }
})