({
	
    getGenderData : function(component) {
		 var action = component.get("c.getGenderList");
        
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.GenderItem", a.getReturnValue());
         });
        $A.enqueueAction(action);

	}
})