({
	doInit : function(component, event, helper) 
    {  //alert('Mohit');
       var action = component.get("c.getRelationList");
       
    
          var self = this;
        action.setCallback(this, function(a) {
            // display the return menu
            
            console.log(a.getReturnValue());
            component.set("v.RelationshipItem", a.getReturnValue());
            
           
            //$A.util.addClass(cid, "slds-active");
            
        });
        $A.enqueueAction(action);
        
        //Calling method to get Gender Data
       helper.getGenderData(component);
	},
    NavigateToPatientInfo : function(component, event, helper)
    {
        
        //Calling Event : 
        var appEvent = $A.get("e.c:PatientComponentCtrlEvent");
        
        /// set event parameter //////
        appEvent.setParams({ "NavigateTo" : 5
                            
                           }
                          );
        appEvent.fire();
    }
    
    

})