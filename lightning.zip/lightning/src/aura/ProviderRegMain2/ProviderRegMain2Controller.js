({
	// This method is call by event handler to get the data from another component.
	redirectUser : function(component, event) 
	{
		// This line used to data from event
		var objUserDetail = event.getParam("objUserDetail");

		// This line is used to set the component attribute
		component.set("v.objUserDetail", objUserDetail);
		var StepNo = event.getParam("StepNo");
		//alert(StepNo);
		component.set("v.Steps", StepNo);
	}
})