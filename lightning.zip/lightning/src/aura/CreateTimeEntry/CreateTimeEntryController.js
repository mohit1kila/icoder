({
    showModalBox : function(component, event, helper) {
        document.getElementById("backGroundSectionId").style.display = "none";
        document.getElementById("newAccountSectionId").style.display = "none";
    },
    AssignValue :function(component, event, helper) {
    },
    
    saveAccount : function(component, event, helper) {
        
        var action = component.get("c.CreateTimeEntry");
        //alert(component.get("v.newTimeEntry"));
        var newTimeEntry= component.get("v.newTimeEntry");
        var AccountId=component.get("v.AccountId");
        newTimeEntry.Account__c=AccountId;
        action.setParams({ "ObjTimeEntry" :newTimeEntry});
        
        action.setCallback(this, function(a) {
            if (a.getState() === "SUCCESS") {
                document.getElementById("backGroundSectionId").style.display = "none";
                document.getElementById("newAccountSectionId").style.display = "none";
                   var newTimeEntry= component.get("v.newTimeEntry");  
                
                newTimeEntry.Name='';
                newTimeEntry.Number_Of_Hours__c='';
                newTimeEntry.Week_Ending__c='';
                newTimeEntry.Id=null;
                
                  var myEvent = $A.get("e.c:TimeEntryViewAccountEvent");
        myEvent.setParams({"SelectedAccountId": null});
        myEvent.fire();
                
                  var myEvent1= $A.get("e.c:TimeEntryViewAccountEvent");
        myEvent1.setParams({"SelectedAccountId": AccountId});
        myEvent1.fire();
                
                component.set("v.newTimeEntry",newTimeEntry);
            } else if (a.getState() === "ERROR") {
                $A.log("Errors", a.getError());
            }
        });
        
        $A.enqueueAction(action);
    },
    /**
     * Handler for receiving the updateLookupIdEvent event
     */
    handleAccountIdUpdate : function(cmp, event, helper) {
        // Get the Id from the Event
        var accountId = event.getParam("sObjectId");

        // Set the Id bound to the View
        cmp.set('v.recordId', accountId);
    },

    /**
     * Handler for receiving the clearLookupIdEvent event
     */
    handleAccountIdClear : function(cmp, event, helper) {
        // Clear the Id bound to the View
        cmp.set('v.recordId', null);
    } 
})